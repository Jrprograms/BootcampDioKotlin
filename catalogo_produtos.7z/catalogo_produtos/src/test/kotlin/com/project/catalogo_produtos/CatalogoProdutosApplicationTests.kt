package com.project.catalogo_produtos

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CatalogoProdutosApplicationTests {

	@Test
	fun contextLoads() {
	}

}
