import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/products")
class ProductController(private val productRepository: ProductRepository) {

    @GetMapping
    fun getAllProducts(): List<Product> {
        return productRepository.findAll()
    }

    @GetMapping("/{id}")
    fun getProductById(@PathVariable id: Long): Product {
        return productRepository.findById(id).orElseThrow { NoSuchElementException("Product not found with id: $id") }
    }

    @PostMapping
    fun createProduct(@RequestBody product: Product): Product {
        return productRepository.save(product)
    }

    @PutMapping("/{id}")
    fun updateProduct(@PathVariable id: Long, @RequestBody updatedProduct: Product): Product {
        val existingProduct = productRepository.findById(id).orElseThrow { NoSuchElementException("Product not found with id: $id") }
        val product = existingProduct.copy(
                name = updatedProduct.name,
                description = updatedProduct.description,
                price = updatedProduct.price
        )
        return productRepository.save(product)
    }

    @DeleteMapping("/{id}")
    fun deleteProduct(@PathVariable id: Long) {
        productRepository.deleteById(id)
    }
}
